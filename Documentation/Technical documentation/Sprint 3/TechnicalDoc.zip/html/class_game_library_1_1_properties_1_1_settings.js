var class_game_library_1_1_properties_1_1_settings =
[
    [ "Location", "class_game_library_1_1_properties_1_1_settings.html#a873e3947b074eec700ab7d0b80cc0bc2", null ]
];