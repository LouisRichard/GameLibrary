var namespaces_dup =
[
    [ "DatabaseManager", "namespace_database_manager.html", null ],
    [ "DataManager", "namespace_data_manager.html", null ],
    [ "GameLibrary", "namespace_game_library.html", "namespace_game_library" ],
    [ "TestLoginRegister", "namespace_test_login_register.html", null ]
];