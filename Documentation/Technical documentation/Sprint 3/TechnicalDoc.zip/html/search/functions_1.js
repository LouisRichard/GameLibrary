var searchData=
[
  ['cancel',['Cancel',['../class_game_library_1_1_add_a_game.html#aa869c3e6b3813c5613fb5971a9ea996e',1,'GameLibrary::AddAGame']]],
  ['checkmail',['CheckMail',['../class_data_manager_1_1_login_register_lib.html#ae7d221315254a0af41cabcf3b83dcb31',1,'DataManager::LoginRegisterLib']]],
  ['checkpassword',['CheckPassword',['../class_data_manager_1_1_login_register_lib.html#ac3e7491c60da938fb50b0bef138c243e',1,'DataManager::LoginRegisterLib']]],
  ['confirm',['Confirm',['../class_game_library_1_1_add_a_game.html#a95e23274d3654e73d837343777bb0855',1,'GameLibrary::AddAGame']]]
];
