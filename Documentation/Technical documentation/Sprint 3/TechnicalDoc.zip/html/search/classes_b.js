var searchData=
[
  ['settings',['Settings',['../class_game_library_1_1_properties_1_1_settings.html',1,'GameLibrary::Properties']]]
];
