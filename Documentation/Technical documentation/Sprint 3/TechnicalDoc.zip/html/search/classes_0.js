var searchData=
[
  ['addagame',['AddAGame',['../class_game_library_1_1_add_a_game.html',1,'GameLibrary']]]
];
