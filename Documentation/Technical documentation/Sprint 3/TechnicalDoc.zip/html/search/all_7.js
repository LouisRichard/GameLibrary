var searchData=
[
  ['insert',['Insert',['../class_database_manager_1_1_execute_query.html#a2ec0a4c5a7387709e8ccbbc0bb61239a',1,'DatabaseManager::ExecuteQuery']]]
];
