var searchData=
[
  ['databasemanager',['DatabaseManager',['../namespace_database_manager.html',1,'']]],
  ['datamanager',['DataManager',['../namespace_data_manager.html',1,'']]]
];
