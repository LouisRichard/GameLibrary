var searchData=
[
  ['user',['User',['../class_data_manager_1_1_user.html#a98d37feea3fd348bf98ed68a3c5c5153',1,'DataManager::User']]]
];
