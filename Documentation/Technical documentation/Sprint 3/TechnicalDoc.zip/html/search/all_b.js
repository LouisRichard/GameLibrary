var searchData=
[
  ['passworddontmatchexception',['PasswordDontMatchException',['../class_data_manager_1_1_password_dont_match_exception.html',1,'DataManager']]],
  ['platformdoesntexistsexception',['PlatformDoesntExistsException',['../class_data_manager_1_1_platform_doesnt_exists_exception.html',1,'DataManager']]]
];
