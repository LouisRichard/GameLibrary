var class_data_manager_1_1_platform_doesnt_exists_exception =
[
    [ "PlatformDoesntExistsException", "class_data_manager_1_1_platform_doesnt_exists_exception.html#a9b4447e523fe94bc07a57a89785c75d0", null ]
];