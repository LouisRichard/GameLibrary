var class_test_login_register_1_1_test_game =
[
    [ "AddAGameWithoutTitle", "class_test_login_register_1_1_test_game.html#a1061d67ebee2a1206380d04186e1fc6b", null ]
];