var class_data_manager_1_1_game =
[
    [ "Game", "class_data_manager_1_1_game.html#ada824e44e1db5b9d5ce1e95fe1ebf4e7", null ]
];