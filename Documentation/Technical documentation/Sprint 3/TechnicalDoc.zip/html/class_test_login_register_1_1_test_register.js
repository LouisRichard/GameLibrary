var class_test_login_register_1_1_test_register =
[
    [ "RegisterUserWithoutConfirmPassword", "class_test_login_register_1_1_test_register.html#a1cde4a9f156f7e70ebb8c5fa75bc82aa", null ],
    [ "RegisterUserWithoutPasswords", "class_test_login_register_1_1_test_register.html#acfce56a7e2a5c516424fce4d9b0027b3", null ],
    [ "RegisterUserWithoutPasswordWithConfirm", "class_test_login_register_1_1_test_register.html#a46ace39411bf3a8af2743a757bba303d", null ],
    [ "TestRegiserWithoutEmail", "class_test_login_register_1_1_test_register.html#ad9e540ffdb9ab933cc1281ae26ad5872", null ],
    [ "TestRegisterButPasswordsArentTheSame", "class_test_login_register_1_1_test_register.html#a4467ecc1997cd2236e16b3f4b58395b5", null ],
    [ "TestRegisterUserThatAlreadyExist", "class_test_login_register_1_1_test_register.html#ab115c334a17061d124d72e8642826d05", null ],
    [ "TestRegisterUserThatDoesntExist", "class_test_login_register_1_1_test_register.html#a62b454dbea99bd5cfc5570a3a35a92ef", null ]
];