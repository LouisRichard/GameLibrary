var searchData=
[
  ['notvalidemailexception',['NotValidEmailException',['../class_data_manager_1_1_not_valid_email_exception.html',1,'DataManager']]]
];
