var searchData=
[
  ['databasemanager',['DatabaseManager',['../namespace_database_manager.html',1,'']]],
  ['datamanager',['DataManager',['../namespace_data_manager.html',1,'']]],
  ['dbconnector',['DbConnector',['../class_database_manager_1_1_db_connector.html',1,'DatabaseManager']]],
  ['delete',['Delete',['../class_database_manager_1_1_execute_query.html#ab8a179c04184b50e08b0b81ea125f4d9',1,'DatabaseManager::ExecuteQuery']]],
  ['dispose',['Dispose',['../class_game_library_1_1_login_register.html#a0e9fae358c83a0c37aa500a07408e508',1,'GameLibrary.LoginRegister.Dispose()'],['../class_game_library_1_1_my_library.html#a10b5882d0046653a1269d2375d6e11ea',1,'GameLibrary.MyLibrary.Dispose()'],['../class_game_library_1_1_register_valid.html#a4c7784d0e97ce90a1d6de045c122db24',1,'GameLibrary.RegisterValid.Dispose()']]]
];
