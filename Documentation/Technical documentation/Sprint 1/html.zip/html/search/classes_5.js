var searchData=
[
  ['loginregister',['LoginRegister',['../class_game_library_1_1_login_register.html',1,'GameLibrary']]],
  ['loginregisterlib',['LoginRegisterLib',['../class_data_manager_1_1_login_register_lib.html',1,'DataManager']]]
];
