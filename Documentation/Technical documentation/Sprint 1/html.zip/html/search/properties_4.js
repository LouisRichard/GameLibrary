var searchData=
[
  ['user',['User',['../class_game_library_1_1_my_library.html#aded3d4aa9e333451dec1d9f6c0afdfe7',1,'GameLibrary.MyLibrary.User()'],['../class_game_library_1_1_register_valid.html#a393f05712b573dab7518f04530d03f44',1,'GameLibrary.RegisterValid.User()']]],
  ['username',['Username',['../class_game_library_1_1_user.html#a12d68a6b6d3a7ab6cf11fb1f18ee13de',1,'GameLibrary::User']]]
];
