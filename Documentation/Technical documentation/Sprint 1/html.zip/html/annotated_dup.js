var annotated_dup =
[
    [ "DatabaseManager", "namespace_database_manager.html", "namespace_database_manager" ],
    [ "DataManager", "namespace_data_manager.html", "namespace_data_manager" ],
    [ "GameLibrary", "namespace_game_library.html", "namespace_game_library" ],
    [ "TestLoginRegister", "namespace_test_login_register.html", "namespace_test_login_register" ]
];