var namespace_data_manager =
[
    [ "CryptoPassword", "class_data_manager_1_1_crypto_password.html", "class_data_manager_1_1_crypto_password" ],
    [ "EmptyFieldException", "class_data_manager_1_1_empty_field_exception.html", "class_data_manager_1_1_empty_field_exception" ],
    [ "FailedDatabaseConnectionException", "class_data_manager_1_1_failed_database_connection_exception.html", "class_data_manager_1_1_failed_database_connection_exception" ],
    [ "GameException", "class_data_manager_1_1_game_exception.html", "class_data_manager_1_1_game_exception" ],
    [ "GameManager", "class_data_manager_1_1_game_manager.html", null ],
    [ "LoginRegisterLib", "class_data_manager_1_1_login_register_lib.html", "class_data_manager_1_1_login_register_lib" ],
    [ "NotValidEmailException", "class_data_manager_1_1_not_valid_email_exception.html", "class_data_manager_1_1_not_valid_email_exception" ],
    [ "PasswordDontMatchException", "class_data_manager_1_1_password_dont_match_exception.html", "class_data_manager_1_1_password_dont_match_exception" ],
    [ "UserAldreadyExistsException", "class_data_manager_1_1_user_aldready_exists_exception.html", "class_data_manager_1_1_user_aldready_exists_exception" ],
    [ "UserDoesntExistException", "class_data_manager_1_1_user_doesnt_exist_exception.html", "class_data_manager_1_1_user_doesnt_exist_exception" ],
    [ "UserManager", "class_data_manager_1_1_user_manager.html", null ],
    [ "WrongPasswordException", "class_data_manager_1_1_wrong_password_exception.html", "class_data_manager_1_1_wrong_password_exception" ]
];