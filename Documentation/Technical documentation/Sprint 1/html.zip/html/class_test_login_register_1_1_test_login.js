var class_test_login_register_1_1_test_login =
[
    [ "LoginWithCorrectParameters", "class_test_login_register_1_1_test_login.html#a591ec2d02c9fc8c29f176d0f19d8c211", null ],
    [ "TestEmailNotValid", "class_test_login_register_1_1_test_login.html#aa9837998f62de7136a4a7e24cbd9fe82", null ],
    [ "TestEmailValid", "class_test_login_register_1_1_test_login.html#aa760b6e4224a30b6193526bacfceb79a", null ],
    [ "TestLoginUserThatdoesntExist", "class_test_login_register_1_1_test_login.html#a4bea5c8095a0b4211f3c55a912f9f05b", null ],
    [ "TestLoginUserWithWrongPassword", "class_test_login_register_1_1_test_login.html#a799e23555fcebf9a86bb35afb1acb81d", null ],
    [ "TestLoginWithoutEmail", "class_test_login_register_1_1_test_login.html#a96648fbc7f9ef293766435027ced0b3c", null ],
    [ "TestLoginWithoutPassword", "class_test_login_register_1_1_test_login.html#acecccb20ef8a2b88b213323669126100", null ]
];