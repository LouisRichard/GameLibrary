var class_data_manager_1_1_not_valid_email_exception =
[
    [ "NotValidEmailException", "class_data_manager_1_1_not_valid_email_exception.html#abe79a5af706a00d7d99bafaea4cb8873", null ]
];