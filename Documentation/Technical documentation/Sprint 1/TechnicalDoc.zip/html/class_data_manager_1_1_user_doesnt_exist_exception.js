var class_data_manager_1_1_user_doesnt_exist_exception =
[
    [ "UserDoesntExistException", "class_data_manager_1_1_user_doesnt_exist_exception.html#a3ce1ee10a75a47866c0bca7fc91acecd", null ]
];