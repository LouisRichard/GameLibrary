var searchData=
[
  ['gameexception',['GameException',['../class_data_manager_1_1_game_exception.html',1,'DataManager']]],
  ['gamemanager',['GameManager',['../class_data_manager_1_1_game_manager.html',1,'DataManager']]]
];
