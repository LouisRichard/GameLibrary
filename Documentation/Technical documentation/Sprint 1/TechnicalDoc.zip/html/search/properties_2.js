var searchData=
[
  ['status',['Status',['../class_data_manager_1_1_login_register_lib.html#a45ae86c24dcdbaf5daa9245f3be9deed',1,'DataManager::LoginRegisterLib']]]
];
