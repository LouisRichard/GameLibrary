var searchData=
[
  ['dbconnector',['DbConnector',['../class_database_manager_1_1_db_connector.html',1,'DatabaseManager']]]
];
