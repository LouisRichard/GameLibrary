var namespace_game_library_1_1_properties =
[
    [ "Resources", "class_game_library_1_1_properties_1_1_resources.html", null ],
    [ "Settings", "class_game_library_1_1_properties_1_1_settings.html", null ]
];