var class_game_library_1_1_my_library =
[
    [ "MyLibrary", "class_game_library_1_1_my_library.html#a072f678844113ed35ee3a7b1b9faffa1", null ],
    [ "AddAGame", "class_game_library_1_1_my_library.html#abd290b15076d7a87ca97f64c611d4f15", null ],
    [ "Dispose", "class_game_library_1_1_my_library.html#a10b5882d0046653a1269d2375d6e11ea", null ],
    [ "User", "class_game_library_1_1_my_library.html#aded3d4aa9e333451dec1d9f6c0afdfe7", null ]
];