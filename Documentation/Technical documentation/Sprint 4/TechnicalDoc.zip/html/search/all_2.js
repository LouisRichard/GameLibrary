var searchData=
[
  ['databasemanager',['DatabaseManager',['../namespace_database_manager.html',1,'']]],
  ['datamanager',['DataManager',['../namespace_data_manager.html',1,'']]],
  ['dbconnector',['DbConnector',['../class_database_manager_1_1_db_connector.html',1,'DatabaseManager']]],
  ['dbexception',['DbException',['../class_data_manager_1_1_db_exception.html',1,'DataManager']]],
  ['delete',['Delete',['../class_database_manager_1_1_execute_query.html#ab8a179c04184b50e08b0b81ea125f4d9',1,'DatabaseManager::ExecuteQuery']]],
  ['deletefromlibrary',['DeleteFromLibrary',['../class_data_manager_1_1_game_manager.html#a8bb9f1f62b827a654baa8a45b0106614',1,'DataManager::GameManager']]],
  ['doubleclic',['DoubleClic',['../class_game_library_1_1_login_register.html#a425f39729e12de215aa1093900ab0794',1,'GameLibrary::LoginRegister']]]
];
