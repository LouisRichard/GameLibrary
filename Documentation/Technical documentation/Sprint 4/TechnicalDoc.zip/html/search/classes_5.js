var searchData=
[
  ['game',['Game',['../class_data_manager_1_1_game.html',1,'DataManager']]],
  ['gamealreadyexistsexception',['GameAlreadyExistsException',['../class_data_manager_1_1_game_already_exists_exception.html',1,'DataManager']]],
  ['gameexception',['GameException',['../class_data_manager_1_1_game_exception.html',1,'DataManager']]],
  ['gamemanager',['GameManager',['../class_data_manager_1_1_game_manager.html',1,'DataManager']]]
];
