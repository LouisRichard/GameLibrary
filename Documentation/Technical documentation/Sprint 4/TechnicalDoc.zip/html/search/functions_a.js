var searchData=
[
  ['update',['Update',['../class_database_manager_1_1_execute_query.html#ab160eb4a29fef35ca3e2797d389f5742',1,'DatabaseManager::ExecuteQuery']]],
  ['user',['User',['../class_data_manager_1_1_user.html#a98d37feea3fd348bf98ed68a3c5c5153',1,'DataManager::User']]]
];
