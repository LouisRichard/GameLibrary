var searchData=
[
  ['title',['Title',['../class_data_manager_1_1_game.html#aa5ef83e355171e26df018e7eb4533cc8',1,'DataManager::Game']]]
];
