var searchData=
[
  ['user',['User',['../class_data_manager_1_1_user.html',1,'DataManager']]],
  ['useraldreadyexistsexception',['UserAldreadyExistsException',['../class_data_manager_1_1_user_aldready_exists_exception.html',1,'DataManager']]],
  ['userdoesntexistexception',['UserDoesntExistException',['../class_data_manager_1_1_user_doesnt_exist_exception.html',1,'DataManager']]],
  ['usermanager',['UserManager',['../class_data_manager_1_1_user_manager.html',1,'DataManager']]]
];
