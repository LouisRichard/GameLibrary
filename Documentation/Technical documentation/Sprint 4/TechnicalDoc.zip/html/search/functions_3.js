var searchData=
[
  ['game',['Game',['../class_data_manager_1_1_game.html#ada824e44e1db5b9d5ce1e95fe1ebf4e7',1,'DataManager::Game']]],
  ['getgameid',['GetGameID',['../class_data_manager_1_1_game_manager.html#aa903ecd39bf13f2f3fce73a81876d567',1,'DataManager::GameManager']]],
  ['getgamelibrary',['GetGameLibrary',['../class_data_manager_1_1_game_manager.html#a0d6ae1c6af89b867d05cfba4504daa17',1,'DataManager::GameManager']]],
  ['getgamelist',['GetGameList',['../class_data_manager_1_1_game_manager.html#aa5b69f99e2c146d7d612c597c6e2d9c2',1,'DataManager::GameManager']]],
  ['getuserid',['GetUserID',['../class_data_manager_1_1_user_manager.html#a1675179ea1d2f26f04faf937c362b469',1,'DataManager::UserManager']]]
];
