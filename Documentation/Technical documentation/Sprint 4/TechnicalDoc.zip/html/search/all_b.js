var searchData=
[
  ['passworddontmatchexception',['PasswordDontMatchException',['../class_data_manager_1_1_password_dont_match_exception.html',1,'DataManager']]],
  ['platform',['Platform',['../class_data_manager_1_1_game.html#aa216d45c164dfa2c5f96282c95c43e4c',1,'DataManager::Game']]],
  ['platformdoesntexistsexception',['PlatformDoesntExistsException',['../class_data_manager_1_1_platform_doesnt_exists_exception.html',1,'DataManager']]]
];
