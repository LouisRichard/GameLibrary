var class_test_login_register_1_1_test_game =
[
    [ "AddAGameToTheLibraryTheUserAlreadyHaves", "class_test_login_register_1_1_test_game.html#a98a21d3f23a9f4f3281106b4338ee4c5", null ],
    [ "AddAGameWithCorrectValues", "class_test_login_register_1_1_test_game.html#a0375234d589a57e7561a0fade0d2aeab", null ],
    [ "AddAGameWithoutAValidPlatform", "class_test_login_register_1_1_test_game.html#a26c88b8cd36bf1ac75ad6f31427896a0", null ],
    [ "AddAGameWithoutPlatform", "class_test_login_register_1_1_test_game.html#a81d11694ed2b4049359c2affca338720", null ],
    [ "AddAGameWithoutTitle", "class_test_login_register_1_1_test_game.html#a1061d67ebee2a1206380d04186e1fc6b", null ],
    [ "AddAGameWithSpecialCharactersInTheTitle", "class_test_login_register_1_1_test_game.html#a6173e092d198149fa0f2be96f3f9f6ec", null ],
    [ "DeleteAGameFromTheLibrary", "class_test_login_register_1_1_test_game.html#af34062460b9912f7261c7233dc2ce4b0", null ]
];