var class_data_manager_1_1_game_already_exists_exception =
[
    [ "GameAlreadyExistsException", "class_data_manager_1_1_game_already_exists_exception.html#a4e2ce5ad0418944f53f58ec82d626feb", null ]
];