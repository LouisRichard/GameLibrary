var class_data_manager_1_1_login_register_exception =
[
    [ "LoginRegisterException", "class_data_manager_1_1_login_register_exception.html#ab3d82e46d1863ebc804f71c28cd56f99", null ]
];