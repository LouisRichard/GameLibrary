var class_data_manager_1_1_game =
[
    [ "Game", "class_data_manager_1_1_game.html#ada824e44e1db5b9d5ce1e95fe1ebf4e7", null ],
    [ "Platform", "class_data_manager_1_1_game.html#aa216d45c164dfa2c5f96282c95c43e4c", null ],
    [ "Title", "class_data_manager_1_1_game.html#aa5ef83e355171e26df018e7eb4533cc8", null ]
];