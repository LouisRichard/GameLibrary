var namespace_database_manager =
[
    [ "DbConnector", "class_database_manager_1_1_db_connector.html", null ],
    [ "ExecuteQuery", "class_database_manager_1_1_execute_query.html", null ]
];