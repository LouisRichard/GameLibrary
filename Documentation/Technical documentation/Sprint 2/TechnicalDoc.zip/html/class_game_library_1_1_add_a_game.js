var class_game_library_1_1_add_a_game =
[
    [ "AddAGame", "class_game_library_1_1_add_a_game.html#a63b40ffef787f410f6642b7593833ea7", null ],
    [ "Cancel", "class_game_library_1_1_add_a_game.html#aa869c3e6b3813c5613fb5971a9ea996e", null ],
    [ "Confirm", "class_game_library_1_1_add_a_game.html#a95e23274d3654e73d837343777bb0855", null ],
    [ "Dispose", "class_game_library_1_1_add_a_game.html#a4034fe3994f27c389bca57140faad7c4", null ],
    [ "User", "class_game_library_1_1_add_a_game.html#aa6532e7caf3063982e1e37937de742ec", null ]
];