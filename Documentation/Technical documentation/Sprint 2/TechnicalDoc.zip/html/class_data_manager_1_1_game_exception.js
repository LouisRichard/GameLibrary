var class_data_manager_1_1_game_exception =
[
    [ "GameException", "class_data_manager_1_1_game_exception.html#aa80eca3ac1484923401313c05edc69fd", null ]
];