var class_data_manager_1_1_failed_database_connection_exception =
[
    [ "FailedDatabaseConnectionException", "class_data_manager_1_1_failed_database_connection_exception.html#a1706b406572ea17635347fb2cdb8f839", null ]
];