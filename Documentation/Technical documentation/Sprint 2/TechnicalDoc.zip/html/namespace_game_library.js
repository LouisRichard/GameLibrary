var namespace_game_library =
[
    [ "Properties", "namespace_game_library_1_1_properties.html", "namespace_game_library_1_1_properties" ],
    [ "AddAGame", "class_game_library_1_1_add_a_game.html", "class_game_library_1_1_add_a_game" ],
    [ "LoginRegister", "class_game_library_1_1_login_register.html", "class_game_library_1_1_login_register" ],
    [ "MyLibrary", "class_game_library_1_1_my_library.html", "class_game_library_1_1_my_library" ],
    [ "RegisterValid", "class_game_library_1_1_register_valid.html", "class_game_library_1_1_register_valid" ]
];