var class_data_manager_1_1_login_register_lib =
[
    [ "LoginLocation", "class_data_manager_1_1_login_register_lib.html#aef5c804768b48e4076c655d3f9be5d7e", null ],
    [ "ValidMail", "class_data_manager_1_1_login_register_lib.html#ab70a39f4db49a06ff8bd198377c8e72a", null ],
    [ "Status", "class_data_manager_1_1_login_register_lib.html#a45ae86c24dcdbaf5daa9245f3be9deed", null ]
];