var class_data_manager_1_1_login_register_lib =
[
    [ "CheckMail", "class_data_manager_1_1_login_register_lib.html#ae7d221315254a0af41cabcf3b83dcb31", null ],
    [ "CheckPassword", "class_data_manager_1_1_login_register_lib.html#ac3e7491c60da938fb50b0bef138c243e", null ],
    [ "ValidMail", "class_data_manager_1_1_login_register_lib.html#ab70a39f4db49a06ff8bd198377c8e72a", null ],
    [ "Status", "class_data_manager_1_1_login_register_lib.html#a45ae86c24dcdbaf5daa9245f3be9deed", null ]
];