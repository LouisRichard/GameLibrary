var class_data_manager_1_1_user =
[
    [ "User", "class_data_manager_1_1_user.html#a98d37feea3fd348bf98ed68a3c5c5153", null ],
    [ "Username", "class_data_manager_1_1_user.html#ab7addf6bad70060a3a5ede91a9f760cc", null ]
];