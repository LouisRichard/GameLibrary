var searchData=
[
  ['gamelibrary',['GameLibrary',['../namespace_game_library.html',1,'']]],
  ['gamemanager',['GameManager',['../class_data_manager_1_1_game_manager.html',1,'DataManager']]],
  ['properties',['Properties',['../namespace_game_library_1_1_properties.html',1,'GameLibrary']]]
];
