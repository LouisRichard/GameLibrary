var searchData=
[
  ['validmail',['ValidMail',['../class_data_manager_1_1_login_register_lib.html#ab70a39f4db49a06ff8bd198377c8e72a',1,'DataManager::LoginRegisterLib']]],
  ['verify',['Verify',['../class_data_manager_1_1_crypto_password.html#a59fe06c1f8a2a574fb5f676d970d2d9e',1,'DataManager::CryptoPassword']]]
];
