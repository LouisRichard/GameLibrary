var searchData=
[
  ['user',['User',['../class_data_manager_1_1_user.html',1,'DataManager.User'],['../class_game_library_1_1_register_valid.html#a393f05712b573dab7518f04530d03f44',1,'GameLibrary.RegisterValid.User()'],['../class_game_library_1_1_add_a_game.html#aa6532e7caf3063982e1e37937de742ec',1,'GameLibrary.AddAGame.User()'],['../class_game_library_1_1_my_library.html#aded3d4aa9e333451dec1d9f6c0afdfe7',1,'GameLibrary.MyLibrary.User()'],['../class_data_manager_1_1_user.html#a98d37feea3fd348bf98ed68a3c5c5153',1,'DataManager.User.User()']]],
  ['useraldreadyexistsexception',['UserAldreadyExistsException',['../class_data_manager_1_1_user_aldready_exists_exception.html',1,'DataManager']]],
  ['userdoesntexistexception',['UserDoesntExistException',['../class_data_manager_1_1_user_doesnt_exist_exception.html',1,'DataManager']]],
  ['usermanager',['UserManager',['../class_data_manager_1_1_user_manager.html',1,'DataManager']]],
  ['username',['Username',['../class_data_manager_1_1_user.html#ab7addf6bad70060a3a5ede91a9f760cc',1,'DataManager::User']]]
];
