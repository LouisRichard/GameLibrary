var searchData=
[
  ['cryptopassword',['CryptoPassword',['../class_data_manager_1_1_crypto_password.html',1,'DataManager']]]
];
