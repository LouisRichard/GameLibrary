var searchData=
[
  ['game',['Game',['../class_data_manager_1_1_game.html',1,'DataManager']]],
  ['gamemanager',['GameManager',['../class_data_manager_1_1_game_manager.html',1,'DataManager']]]
];
