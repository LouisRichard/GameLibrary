var searchData=
[
  ['faileddatabaseconnectionexception',['FailedDatabaseConnectionException',['../class_data_manager_1_1_failed_database_connection_exception.html',1,'DataManager']]]
];
