var searchData=
[
  ['addagame',['AddAGame',['../class_game_library_1_1_my_library.html#abd290b15076d7a87ca97f64c611d4f15',1,'GameLibrary::MyLibrary']]],
  ['addgametogamelist',['AddGameToGameList',['../class_data_manager_1_1_game_manager.html#aef4a7c6721aac0f4050798ef10391694',1,'DataManager::GameManager']]]
];
