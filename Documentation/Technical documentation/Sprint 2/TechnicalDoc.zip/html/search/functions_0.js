var searchData=
[
  ['delete',['Delete',['../class_database_manager_1_1_execute_query.html#ab8a179c04184b50e08b0b81ea125f4d9',1,'DatabaseManager::ExecuteQuery']]]
];
