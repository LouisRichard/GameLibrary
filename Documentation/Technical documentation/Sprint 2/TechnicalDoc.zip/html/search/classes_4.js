var searchData=
[
  ['gamemanager',['GameManager',['../class_data_manager_1_1_game_manager.html',1,'DataManager']]]
];
