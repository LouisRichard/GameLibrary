var class_data_manager_1_1_db_exception =
[
    [ "DbException", "class_data_manager_1_1_db_exception.html#a4cd2400ce15ec25fd06292246f72537c", null ]
];